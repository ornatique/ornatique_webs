<?php

namespace App\Http\Controllers\Designer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ApplyController extends Controller
{
    public function apply_now()
    {
        return view('designer.apply');
    }

    public function get_otp()
    {
        return view('designer.apply_otp');
    }


    public function form()
    {
        return view('designer.apply_form');
    }
}
