<form method="post" action="{{ route('profile') }}" enctype="multipart/form-data">
    @csrf

    @if ($errors->any())
        {!! implode('', $errors->all('<div>:message</div>')) !!}
    @endif


    <input class="d-none" type="file" id="avtar" name="avtar" accept="image/*">
    <input type="hidden" value="{{ Auth::id() }}" name="user_id">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="fname" class="placeholder"><b>First name</b></label>
                <input id="fname" name="name" type="text" class="form-control" required="" value="">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="lname" class="placeholder"><b>Last name</b></label>
                <input id="lname" name="last_name" type="text" class="form-control" required="" value=>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label for="email" class="placeholder"><b>Email</b></label>
                <input id="email" name="email" type="email" class="form-control" required="" value="">
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="contact" class="placeholder"><b>Contact</b></label>
                <input id="contact" name="contact" type="number" class="form-control" required="" value="">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <p class="mb-1 placeholder"><b>Your Gender</b></p>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="inlineRadio1Male" value="M">
                {{-- {{ $data->gender == 'M' ? 'checked' : '' }} --}}
                <label class="form-check-label" for="inlineRadio1Male">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="gender" id="inlineRadioFemale" value="F">
                {{-- {{ $data->gender == 'F' ? 'checked' : '' }} --}}
                <label class="form-check-label" for="inlineRadioFemale">Female</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="dob" class="placeholder"><b>Date of Birth</b></label>
                <input id="dob" name="dob" type="date" class="form-control" required="" value="">
            </div>
        </div>
    </div>
    <input type="hidden" value="" name="id">
    <div class="text-center my-2">
        <button class="btn btn-primary">Update Profile</button>
    </div>
</form>
