@extends('frontend.template')
@section('main')

    <section class="wishlist-page">
        <div class="container">
            <!-- Breadcrumb Section -->
            <div class="breadcrumb-sec">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Wishlist</li>
                    </ol>
                </nav>
            </div>

            <div class="wishlist-list-outer">
                <h2 class="inner-page-title">WISHLIST</h2>

                <div class="wishlist-list">
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="wishlist-item">
                        <div class="product-list product-list-overlay">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <div class="product-btn-group">
                                            <div>
                                                <button type="button" class="yellow-btn">
                                                    <div class="button_inner"><span data-text="MOVE TO CART">MOVE TO
                                                            CART</span></div>
                                                </button>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-round">MOVE TO CART</button>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>



@stop
