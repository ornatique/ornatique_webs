<form action="{{ route('address_edit', ['id' => $data->id]) }}" method="POST">
    @csrf
    <div class="col">
        <label class="control-label" for="name">Name</label>
        <input required type="text" class="form-control required @error('name') is-invalid @enderror" id="name"
            placeholder="Enter Name" name="name" value="{{ $data['name'] }}">
        @error('name')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="col">
        <label class="control-label" for="last_name">Last Name</label>
        <input type="text" class="form-control required @error('last_name') is-invalid @enderror" id="last_name"
            placeholder="Enter Last Name" name="last_name" value="{{ $data['last_name'] }}">
        @error('last_name')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="col">
        <label class="control-label" for="contact">Contact</label>
        <input required type="number" class="form-control required @error('contact') is-invalid @enderror" id="contact"
            placeholder="Enter contact" name="contact" value="{{ $data['contact'] }}">
        @error('contact')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="row mb-3">
        <div class="col">
            <label class="control-label" for="address">Address</label>
            <textarea required type="text" class="form-control required  @error('address') is-invalid @enderror" id="address"
                placeholder="Enter Address" name="address" value="" rows="3">{{ $data['address'] }}</textarea>
            @error('address')
                <span class="invalid-feedback" role="alert">
                    <strong class="text-danger">{{ $message }}</strong>
                </span>
            @enderror
        </div>
    </div>

    <div class="col">
        <label class="control-label" for="area">Area</label>
        <input required type="text" class="form-control required  @error('area') is-invalid @enderror" id="area"
            placeholder="Enter Area" name="area" value="{{ $data['area'] }}">
        @error('city')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="col">
        <label class="control-label" for="city">City</label>
        <input required type="text" class="form-control required  @error('city') is-invalid @enderror" id="city"
            placeholder="Enter City" name="city" value="{{ $data['city'] }}">
        @error('city')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="col">
        <label class="control-label" for="state">State</label>
        <input required type="text" class="form-control required @error('city') is-invalid @enderror" id="state"
            placeholder="Enter State" name="state" value="{{ $data['state'] }}">
        @error('state')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="col">
        <label class="control-label" for="pincode">PinCode</label>
        <input required type="number" class="form-control required @error('pincode') is-invalid @enderror" id="pincode"
            placeholder="Enter PinCode" name="pincode" value="{{ $data['pincode'] }}">
        @error('pincode')
            <span class="invalid-feedback" role="alert">
                <strong class="text-danger">{{ $message }}</strong>
            </span>
        @enderror
    </div>

    <div class="row">
        <div class="col">
            <button type="submit" class="btn btn-primary btn-sm">SUBMIT</button>
        </div>
    </div>
</form>
