@extends('frontend.template')
@section('main')
    <main>
        <section class="ban-slider">
            <div class="container-fluid onscroll-full">
                <div class="row">
                    <div class="col-12">
                        <div class="banner-slider" style="height: 500px; overflow: hidden">
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section product-list-wrap">
            <div class="container">
                <div class="filter-product-list">
                    <div class="filter-toggle d-block d-md-none">
                        <a class="btn filter-toggle-btn" href="#filter-sidebar">
                            Digital Assests Filter
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12 filters sliding-sidebar" id="filter-sidebar">
                            <a href="#" class="close-filter d-block d-md-none">
                                <i class="fas fa-times"></i>
                            </a>
                            <aside class="mb-3 px-2 filter-aside">
                                <h4>Digital Assets</h4>
                                <form action="" id="productForm">
                                    <div class="filter-section">
                                        <div class="form-group mb-0 position-relative">
                                            <span class="search-icon"><i class="fas fa-search"></i></span>
                                            <input type="text" class="form-control" placeholder="Search"
                                                aria-label="Search Category">
                                        </div>
                                        <div class="accordion" id="accordionCategoery">
                                            <div class="card">
                                                <div class="card-head" id="headingOne">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseOne" aria-expanded="true"
                                                        aria-controls="collapseOne">
                                                        Category
                                                    </h6>
                                                </div>
                                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                                    data-parent="#accordionCategoery">
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-section">
                                        <div class="accordion" id="accordionColor">
                                            <div class="card">
                                                <div class="card-head" id="headingTwo">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseTwo" aria-expanded="true"
                                                        aria-controls="collapseTwo">
                                                        Color
                                                    </h6>
                                                </div>
                                                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo"
                                                    data-parent="#accordionColor">
                                                    <div class="card-body">
                                                        <div class="select-color">
                                                            <input type="checkbox" id="purple" name="color" value="purple">
                                                            <label class="purple" for="purple"></label>
                                                            <input type="checkbox" id="skyblue" name="color"
                                                                value="skyblue">
                                                            <label class="skyblue" for="skyblue"></label>
                                                            <input type="checkbox" id="black" name="color" value="black">
                                                            <label class="black" for="black"></label>
                                                            <input type="checkbox" id="yellow" name="color" value="yellow">
                                                            <label class="yellow" for="yellow"></label>
                                                            <input type="checkbox" id="orange" name="color" value="orange">
                                                            <label class="orange" for="orange"></label>
                                                            <input type="checkbox" id="skyblue" name="color"
                                                                value="skyblue">
                                                            <label class="skyblue" for="skyblue"></label>
                                                            <input type="checkbox" id="black" name="color" value="black">
                                                            <label class="black" for="black"></label>
                                                            <input type="checkbox" id="yellow" name="color" value="yellow">
                                                            <label class="yellow" for="yellow"></label>
                                                            <input type="checkbox" id="orange" name="color" value="orange">
                                                            <label class="orange" for="orange"></label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="filter-section">
                                        <div class="form-group mb-0 position-relative">
                                            <span class="search-icon"><i class="fas fa-search"></i></span>
                                            <input type="text" class="form-control" placeholder="Search"
                                                aria-label="Search Category">
                                        </div>
                                        <div class="accordion" id="accordionArtist">
                                            <div class="card">
                                                <div class="card-head" id="headingFour">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseFour" aria-expanded="true"
                                                        aria-controls="collapseFour">
                                                        Artist
                                                    </h6>
                                                </div>
                                                <div id="collapseFour" class="collapse show" aria-labelledby="headingFour"
                                                    data-parent="#accordionArtist">
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-btn-group">
                                        <div class="filter-btn">
                                            <button type="button" class="btn btn-black-brd" id="submit-form">Apply</button>
                                            <a href="#" class="btn btn-cancel">
                                                <div class="button_inner"><span data-text="Add to Cart">Cancel
                                                    </span></div>
                                            </a>
                                        </div>
                                    </div>
                                </form>
                            </aside>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12">
                            <div id="filterd_product">
                                <div class="row">
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-3.jpg"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-3.jpg"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="product-list">
                                            <div class="arrival-info">
                                                <a href="#">
                                                    <div class="product-img">
                                                        <span class="wishlist">
                                                            <i class='fal fa-heart'></i>
                                                        </span>
                                                        <figure>
                                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                                alt="product-image">
                                                        </figure>
                                                    </div>
                                                    <div class="arrival-content">
                                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                        <div class="price-list"> <span
                                                                class="grey-text">₹599</span>
                                                            ₹399<span class="percent">Save 8%</span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="trending-product">
                    <h2>Trending Digital Assets</h2>
                    <div class="trending-product-list">
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </main>
@stop
