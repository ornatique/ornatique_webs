@extends('frontend.template')
@section('main')
    <section class="product-detail-main">
        <div class="container">
            <section class="product-detail">
                <div class="row">
                    <div class="col-12 col-xl-5">
                        <div class="product-slider">
                            <div class="slider slider-for">
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                            </div>


                            <div class="slider slider-nav">
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7">
                        <div class="product-content">
                            <div class="title-rating">
                                <div class="product-title">
                                    <h3>
                                        Striped Captain America Printed Badge Full Sleeve T-Shirt
                                    </h3>
                                    <small>Design by
                                        @ steave
                                    </small>
                                </div>
                                <div class="wishlist-star">
                                    <a href="#" class="wishlist">
                                        <i class='fal fa-heart'></i>
                                    </a>
                                    <div id="stars-group">
                                        <div class="rating-group">
                                            <input class="rating__input rating__input--none" checked name="rating2"
                                                id="rating2-0" value="0" type="radio">
                                            <label aria-label="0 stars" class="rating__label"
                                                for="rating2-0">&nbsp;</label>
                                            <label aria-label="0.5 stars" class="rating__label rating__label--half"
                                                for="rating2-05"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-05" value="0.5"
                                                type="radio">
                                            <label aria-label="1 star" class="rating__label" for="rating2-10"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-10" value="1"
                                                type="radio">
                                            <label aria-label="1.5 stars" class="rating__label rating__label--half"
                                                for="rating2-15"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-15" value="1.5"
                                                type="radio">
                                            <label aria-label="2 stars" class="rating__label" for="rating2-20"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-20" value="2"
                                                type="radio">
                                            <label aria-label="2.5 stars" class="rating__label rating__label--half"
                                                for="rating2-25"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-25" value="2.5"
                                                type="radio" checked>
                                            <label aria-label="3 stars" class="rating__label" for="rating2-30"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-30" value="3"
                                                type="radio">
                                            <label aria-label="3.5 stars" class="rating__label rating__label--half"
                                                for="rating2-35"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-35" value="3.5"
                                                type="radio">
                                            <label aria-label="4 stars" class="rating__label" for="rating2-40"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-40" value="4"
                                                type="radio">
                                            <label aria-label="4.5 stars" class="rating__label rating__label--half"
                                                for="rating2-45"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-45" value="4.5"
                                                type="radio">
                                            <label aria-label="5 stars" class="rating__label" for="rating2-50"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-50" value="5"
                                                type="radio">
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="select-qty">
                                <span>Select Qty.</span>
                                <div class="qty-input">
                                    <button type="button" id="sub" class="sub qty-count">-</button>
                                    <input class="count" type="text" id="1" value="1" min="1" max="100" />
                                    <button type="button" id="add" class="add qty-count">+</button>
                                </div>
                            </div>
                            <div class="btn-group">
                                <a href="#" class="yellow-btn">
                                    <div class="button_inner"><span data-text="Add to Cart">Add to Cart</span></div>
                                </a>
                                <a href="#" class="yellow-btn">
                                    <div class="button_inner"><span data-text="Buy Now">Buy Now</span></div>
                                </a>
                            </div>
                            <div class="pincode-sharing">
                                <div class="pincode-input">
                                    <input class="form-control" type="text" placeholder="Enter Pincode">
                                    <button class="btn btn-check">CHECK</button>
                                </div>
                                <div class="share-social">
                                    <div class="social-links">
                                        <p>Share At: </p>
                                        <a href="#">
                                            <i class="fab fa-whatsapp"></i>
                                        </a>
                                        <a href="#">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                        <a href="#">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Product detail and description tab section -->
            <section class="product-detail-tab">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Product Detail</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Product Desctiption</a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="tabs-1" role="tabpanel">
                        <div class="inner-tab-content">
                            <p>
                                There are many variations of passages of Lorem Ipsum available, but the majority have
                                suffered alteration in some form, by injected humour, or randomised words which don't look
                                even slightly believable. If you are going. There are many variations of passages of Lorem
                                Ipsum available, but the majority have sufThere are many variations of passages of Lorem
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour,
                                or randomised words which don't look even slightly believable. If you are going.fered
                                alteration in some form, by injected humour, or randomised words which don't look even
                                slightly believable. If you are going.
                            </p>
                        </div>
                    </div>
                    <div class="tab-pane" id="tabs-2" role="tabpanel">
                        <div class="inner-tab-content">
                            <p>
                                There are many variations of passages of Lorem Ipsum available, but the majority have
                                suffered alteration in some form, by injected humour, or randomised words which don't look
                                even slightly believable. If you are going. There are many variations of passages of Lorem
                                Ipsum available, but the majority have sufThere are many variations of passages of Lorem
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour,
                                or randomised words which don't look even slightly believable. If you are going.fered
                                alteration in some form, by injected humour, or randomised words which don't look even
                                slightly believable. If you are going.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            <section class="similar-product">
                <h2>SIMILAR PRODUCT</h2>
                <div class="similar-product-slider">
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span>
                                            ₹399<span class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- Digintal section -->
            <section class="digital-assets">
                <div class="d-flex align-items-center justify-content-between title-section">
                    <h2 class="inner-page-title">DIGITAL ASSETS</h2>
                    <div class="d-flex flex-wrap justify-content-end button-right">
                        <span class="w-100 text-right sub-title">What is Digital Assets?</span>
                        <a href="#" class="yellow-btn">
                            <div class="button_inner"><span data-text="Watch Video">Watch Video</span></div>
                        </a>
                    </div>
                </div>
                <div class="digital-product-content">
                    <div class="digital-product-list">

                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>


@stop
