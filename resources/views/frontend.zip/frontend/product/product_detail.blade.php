@extends('frontend.template')
@section('main')
    <section class="product-detail-main">
        <div class="container">
            <section class="product-detail">
                <div class="row">
                    <div class="col-12 col-xl-5">
                        <div class="product-slider">
                            <div class="slider slider-for">
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product') . '/' . $data->thumbnail }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                @if ($data->gallery)
                                    <?php $images = json_decode($data->gallery); ?>
                                    @foreach ($images as $image)
                                        <div>
                                            <div class="product-img">
                                                <img src="{{ asset('public/assets/images/product') . '/' . $image }}"
                                                    alt="product-image">
                                            </div>
                                        </div>
                                    @endforeach
                                    {{-- <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-img">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div> --}}
                            </div>
                            @endif
                            <div class="slider slider-nav">
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product') . '/' . $data->thumbnail }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                @if ($data->gallery)
                                    @foreach ($images as $image)
                                        <div>
                                            <div class="product-thumb">
                                                <img src="{{ asset('public/assets/images/product') . '/' . $image }}"
                                                    alt="product-image">
                                            </div>
                                        </div>
                                    @endforeach
                                @endif
                                {{-- <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div>
                                <div>
                                    <div class="product-thumb">
                                        <img src="{{ asset('public/assets/images/product-img-3.jpg') }}"
                                            alt="product-image">
                                    </div>
                                </div> --}}
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-xl-7">
                        <div class="product-content">
                            <div class="title-rating">
                                <div class="product-title">
                                    <h3>
                                        {{-- Striped Captain America Printed Badge Full Sleeve T-Shirt --}}
                                        {{ ucfirst($data->name) }}</h3>
                                    <small>Design by @
                                        {{-- @steave --}}
                                        {{ ucfirst($data->user->name) }}
                                    </small>
                                </div>
                                <div class="wishlist-star">
                                    <a href="#" class="wishlist">
                                        <span class="favourite"><i class='fal fa-heart'></i></span>
                                        <span class="un-favourite" hidden><i class='fa fa-heart text-danger'></i></span>
                                    </a>
                                    <div id="stars-group">
                                        <div class="rating-group">
                                            <input class="rating__input rating__input--none" checked name="rating2"
                                                id="rating2-0" value="0" type="radio">
                                            <label aria-label="0 stars" class="rating__label"
                                                for="rating2-0">&nbsp;</label>
                                            <label aria-label="0.5 stars" class="rating__label rating__label--half"
                                                for="rating2-05"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-05" value="0.5"
                                                type="radio">
                                            <label aria-label="1 star" class="rating__label" for="rating2-10"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-10" value="1"
                                                type="radio">
                                            <label aria-label="1.5 stars" class="rating__label rating__label--half"
                                                for="rating2-15"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-15" value="1.5"
                                                type="radio">
                                            <label aria-label="2 stars" class="rating__label" for="rating2-20"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-20" value="2"
                                                type="radio">
                                            <label aria-label="2.5 stars" class="rating__label rating__label--half"
                                                for="rating2-25"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-25" value="2.5"
                                                type="radio" checked>
                                            <label aria-label="3 stars" class="rating__label" for="rating2-30"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-30" value="3"
                                                type="radio">
                                            <label aria-label="3.5 stars" class="rating__label rating__label--half"
                                                for="rating2-35"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-35" value="3.5"
                                                type="radio">
                                            <label aria-label="4 stars" class="rating__label" for="rating2-40"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-40" value="4"
                                                type="radio">
                                            <label aria-label="4.5 stars" class="rating__label rating__label--half"
                                                for="rating2-45"><i
                                                    class="rating__icon rating__icon--star fa fa-star-half"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-45" value="4.5"
                                                type="radio">
                                            <label aria-label="5 stars" class="rating__label" for="rating2-50"><i
                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                            <input class="rating__input" name="rating2" id="rating2-50" value="5"
                                                type="radio">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="price-list">₹{{ min(json_decode($data->sale_price)) }}
                                <span class="grey-text mr-2">
                                    ₹{{ max(json_decode($data->regular_price)) . ' ' }}
                                </span>
                                <span class="percent">
                                    @if ($data->discount)
                                        Save {{ $data->discount }}{{ $data->flat == 1 ? ' Flat' : '%' }}
                                        OFF
                                    @endif
                                </span>
                            </div>
                            <div class="product-size-color">
                                <div class="size-box">
                                    <h5>Select Size</h5>
                                    <div class="select-size">
                                        @foreach ($data->product_detail as $i => $p)
                                            <input type="radio" class="variant"
                                                id="{{ $p->size_id->id . $p->size_id->name . $i }}" name="size"
                                                value="{{ $p->size_id->id }}" checked>
                                            <label
                                                for="{{ $p->size_id->id . $p->size_id->name . $i }}">{{ $p->size_id->name }}</label>
                                        @endforeach
                                    </div>
                                    <p class="notify">Size not available? <a href="">Notify Me</a> </p>
                                </div>
                                <div class="color-variant">
                                    <h5>Select Color</h5>
                                    <div class="select-color">
                                        @foreach ($data->product_detail as $p)
                                            <input type="radio" class="variant"
                                                id="{{ $p->color_id->id . $p->color_id->color_code . $i }}" name="color"
                                                value="{{ $p->color_id->id }}" checked>
                                            <label class="black"
                                                for="{{ $p->color_id->id . $p->color_id->color_code . $i }}"
                                                style="background-color:{{ $p->color_id->color_code }};color:white"
                                                class="black"></label>
                                        @endforeach
                                    </div>
                                    <p class="notify">Color not available? <a href="">Notify Me</a> </p>
                                </div>
                            </div>
                            {{-- <input type="radio" id="purple" name="color" value="purple">
                                            <label class="purple" for="purple"></label>
                                            <input type="radio" id="skyblue" name="color" value="skyblue">
                                            <label class="skyblue" for="skyblue"></label>
                                            <input type="radio" id="black" name="color" value="black">
                                            <label class="black" for="black"></label>
                                            <input type="radio" id="yellow" name="color" value="yellow">
                                            <label class="yellow" for="yellow"></label>
                                            <input type="radio" id="orange" name="color" value="orange">
                                            <label class="orange" for="orange"></label> --}}


                            {{-- <div class="product-size-color">
                                <div class="size-box">
                                    <h5>Select Size</h5>
                                    <div class="select-size">
                                        <input type="radio" id="xs" name="size" value="XS">
                                        <label for="xs">XS</label>
                                        <input type="radio" id="s" name="size" value="S">
                                        <label for="s">S</label>
                                        <input type="radio" id="m" name="size" value="M">
                                        <label for="m">M</label>
                                        <input type="radio" id="l" name="size" value="L">
                                        <label for="l">L</label>
                                        <input type="radio" id="xl" name="size" value="XL">
                                        <label for="xl">XL</label>
                                        <input type="radio" id="xxl" name="size" value="XXL">
                                        <label for="xxl">XXL</label>
                                    </div>
                                    <p class="notify">Size not available? <a href="">Notify Me</a> </p>
                                </div>
                                <div class="color-variant">
                                    <h5>Select Color</h5>
                                    <div class="select-color">
                                        <input type="radio" id="blue" name="color" value="blue">
                                        <label class="blue" for="blue"></label>
                                        <input type="radio" id="purple" name="color" value="purple">
                                        <label class="purple" for="purple"></label>
                                        <input type="radio" id="skyblue" name="color" value="skyblue">
                                        <label class="skyblue" for="skyblue"></label>
                                        <input type="radio" id="black" name="color" value="black">
                                        <label class="black" for="black"></label>
                                        <input type="radio" id="yellow" name="color" value="yellow">
                                        <label class="yellow" for="yellow"></label>
                                        <input type="radio" id="orange" name="color" value="orange">
                                        <label class="orange" for="orange"></label>
                                    </div>
                                    <p class="notify">Color not available? <a href="">Notify Me</a> </p>
                                </div>
                            </div> --}}
                            <div class="select-qty">
                                <span>Select Qty.</span>
                                <div class="qty-input">
                                    <button type="button" id="sub" class="sub qty-count">-</button>
                                    <input class="count" type="text" id="1" value="1" min="1" max="100" />
                                    <button type="button" id="add" class="add qty-count">+</button>
                                </div>
                            </div>
                            <div class="btn-group">
                                <a href="#" class="yellow-btn">
                                    <div class="button_inner"><span data-text="Add to Cart">Add to Cart</span></div>
                                </a>
                                <a href="#" class="yellow-btn">
                                    <div class="button_inner"><span data-text="Buy Now">Buy Now</span></div>
                                </a>
                            </div>
                            <div class="pincode-sharing">
                                <div class="pincode-input">
                                    <input class="form-control" type="text" placeholder="Enter Pincode">
                                    <button class="btn btn-check">CHECK</button>
                                </div>
                                <div class="share-social">
                                    <div class="social-links">
                                        <p>Share At: </p>
                                        <a href="#">
                                            <i class="fab fa-whatsapp"></i>
                                        </a>
                                        <a href="#">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                        <a href="#">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- @endforeach --}}
                </div>
            </section>
            <!-- Product detail and description tab section -->
            <section class="product-detail-tab">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#tabs-1" role="tab">Product Detail</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#tabs-2" role="tab">Product Desctiption</a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="tabs-1" role="tabpanel">
                        <div class="inner-tab-content">
                            <p>
                                <?php echo htmlspecialchars_decode($data->details); ?>
                            </p>
                        </div>
                    </div>
                    <div class="tab-pane" id="tabs-2" role="tabpanel">
                        <div class="inner-tab-content">
                            <p>
                                <?php echo htmlspecialchars_decode($data->description); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Similar Product section -->
            @isset($products)
                <section class="similar-product">
                    <h2>SIMILAR PRODUCT</h2>
                    <div class="similar-product-slider">
                        @foreach ($products as $product)
                            <div>
                                <div class="product-list">
                                    <div class="arrival-info">
                                        <a href="#">
                                            <div class="product-img">
                                                <span class="wishlist">
                                                    <i class='fal fa-heart'></i>
                                                </span>
                                                <figure>
                                                    <img src="{{ asset('public/assets/images/product') . '/' . $product->thumbnail }}"
                                                        alt="product-image">
                                                </figure>
                                            </div>
                                            <div class="arrival-content">
                                                <h3>{{ ucfirst($product->name) }}</h3>
                                                <div class="price-list"> <span
                                                        class="grey-text">₹{{ max(json_decode($product->regular_price)) }}</span>
                                                    ₹{{ min(json_decode($product->sale_price)) }}
                                                    <span class="percent">
                                                        @if ($data->discount)
                                                            Save
                                                            {{ $data->discount }}{{ $data->flat == 1 ? ' Flat' : '%' }}
                                                            OFF
                                                        @endif
                                                    </span>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </section>
            @endisset
            {{-- <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                            <div class="price-list"> <span class="grey-text">₹599</span>
                                                ₹399<span class="percent">Save 8%</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div> --}}

            <!-- Digintal section -->
            <section class="digital-assets">
                <div class="d-flex align-items-center justify-content-between title-section">
                    <h2 class="inner-page-title">DIGITAL ASSETS</h2>
                    <div class="d-flex flex-wrap justify-content-end button-right">
                        <span class="w-100 text-right sub-title">What is Digital Assets?</span>
                        <a href="#" class="yellow-btn">
                            <div class="button_inner"><span data-text="Watch Video">Watch Video</span></div>
                        </a>
                    </div>
                </div>
                <div class="digital-product-content">
                    <div class="digital-product-list">
                        @foreach ($assets as $asset)
                            <div class="product-list product-list-digital">
                                <div class="arrival-info">
                                    <a href="#">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="{{ asset('public/assets/images/digitalassets') . '/' . $asset->image }}"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>{{ $asset->name }}</h3>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="price-list">
                                                    <span class="price">
                                                        ₹{{ $asset->sale }}
                                                    </span>
                                                    <div>
                                                        <span class="grey-text">₹{{ $asset->regular_price }}</span>
                                                        <span class="percent">
                                                            @if ($asset->discount)
                                                                Save
                                                                {{ $asset->discount }}{{ $asset->flat == 1 ? ' Flat' : '%' }}
                                                                OFF
                                                            @endif
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="created-by">
                                                    <span class="crerated-img">
                                                        <img src="{{ asset('public/assets/images/creators') . '/' . $asset->creator->user->image }}"
                                                            alt="product-image">
                                                    </span>
                                                    <div class="text">
                                                        <span class="gray-text">Created by</span>
                                                        <span class="name">@
                                                            {{ $asset->creator->user->name }}</span>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="overlay-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                <img src="{{ asset('public/assets/images/digitalassets') . '/' . $asset->image }}"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        @endforeach
                        {{-- <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list product-list-digital">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div class="price-list">
                                                <span class="price">
                                                    ₹399
                                                </span>
                                                <div>
                                                    <span class="grey-text">₹599</span>
                                                    <span class="percent">Save 8%</span>
                                                </div>
                                            </div>
                                            <div class="created-by">
                                                <span class="crerated-img">
                                                    <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                        alt="product-image">
                                                </span>
                                                <div class="text">
                                                    <span class="gray-text">Created by</span>
                                                    <span class="name">@SharonTS</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="overlay-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                </a>
                            </div>
                        </div> --}}
                    </div>
                </div>
            </section>
        </div>
    </section>

    <script src="{{ asset('public/assets/js/jquery.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            var variant = [];
            // alert();
            $('.color,.size').click(function() {
                var size = 1;
                var color = 1;
                alert($(this).val());
            })


            $("input[type=radio]").click(function() {
                if ($('input[type=radio][name=color]:checked').length == 0) {
                    alert("Please Select Color");
                    return;
                }
                if ($('input[type=radio][name=size]:checked').length == 0) {
                    alert("Please Select Size");
                    return;
                }
            });

            $('.wishlist').click(function() {

            });


        })
    </script>
@stop
