@extends('frontend.template')
@section('main')
    <main>
        <section class="ban-slider">
            <div class="container-fluid onscroll-full">
                <div class="row">
                    <div class="col-12">
                        <div class="banner-slider" style="height: 500px; overflow: hidden">
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                            <figure><img style="width: 100%;height: 500px; object-fit: cover"
                                    src="{{ asset('public/assets/images/banner-slide.jpg') }}" alt="Slider Image">
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="section product-list-wrap">
            <div class="container">
                <div class="filter-product-list">
                    <div class="filter-toggle d-block d-md-none">
                        <a class="btn filter-toggle-btn" href="#filter-sidebar">
                            Product Filter
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12 filters sliding-sidebar" id="filter-sidebar">
                            <a href="#" class="close-filter d-block d-md-none">
                                <i class="fas fa-times"></i>
                            </a>
                            <aside class="mb-3 px-2 filter-aside">
                                <h4>Men's Collection</h4>
                                <form action="" id="productForm">
                                    <div class="filter-section">
                                        <div class="form-group mb-0 position-relative">
                                            <span class="search-icon"><i class="fas fa-search"></i></span>
                                            <input type="text" class="form-control" placeholder="Search"
                                                aria-label="Search Category">
                                        </div>
                                        <div class="accordion" id="accordionCategoery">
                                            <div class="card">
                                                <div class="card-head" id="headingOne">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseOne" aria-expanded="true"
                                                        aria-controls="collapseOne">
                                                        Category
                                                    </h6>
                                                </div>
                                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                                    data-parent="#accordionCategoery">
                                                    <div class="card-body">
                                                        @foreach ($categories as $cat)
                                                            <div class="form-group">
                                                                <label class="custom-checkbox">{{ ucfirst($cat->name) }}
                                                                    <input type="checkbox" name="category[]"
                                                                        value="{{ $cat->id }}">
                                                                    <span class="checkmark"></span>
                                                                </label>
                                                            </div>
                                                        @endforeach
                                                        {{-- <div class="form-group">
                                          <label class="custom-checkbox">Nature background
                                          <input type="checkbox">
                                          <span class="checkmark"></span>
                                          </label>
                                       </div>
                                       <div class="form-group">
                                          <label class="custom-checkbox">Nature background
                                          <input type="checkbox">
                                          <span class="checkmark"></span>
                                          </label>
                                       </div>
                                       <div class="form-group">
                                          <label class="custom-checkbox">Nature background
                                          <input type="checkbox">
                                          <span class="checkmark"></span>
                                          </label>
                                       </div>
                                       <div class="form-group">
                                          <label class="custom-checkbox">Nature background
                                          <input type="checkbox">
                                          <span class="checkmark"></span>
                                          </label>
                                       </div> --}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-section">
                                        <div class="accordion" id="accordionColor">
                                            <div class="card">
                                                <div class="card-head" id="headingTwo">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseTwo" aria-expanded="true"
                                                        aria-controls="collapseTwo">
                                                        Color
                                                    </h6>
                                                </div>
                                                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo"
                                                    data-parent="#accordionColor">
                                                    <div class="card-body">
                                                        <div class="select-color">
                                                            @foreach ($colors as $color)
                                                                <input type="checkbox" name="color[]"
                                                                    id="{{ $color->color_code }}" name="color"
                                                                    value="{{ $color->id }}">
                                                                <label class="blue"
                                                                    style="background-color: {{ $color->color_code }}"
                                                                    for="{{ $color->color_code }}"></label>
                                                            @endforeach

                                                            {{-- <input type="checkbox" id="purple" name="color" value="purple">
                                                            <label class="purple" for="purple"></label>

                                                            <input type="checkbox" id="skyblue" name="color"
                                                                value="skyblue">
                                                            <label class="skyblue" for="skyblue"></label>
                                                            <input type="checkbox" id="black" name="color" value="black">
                                                            <label class="black" for="black"></label>
                                                            <input type="checkbox" id="yellow" name="color" value="yellow">
                                                            <label class="yellow" for="yellow"></label>
                                                            <input type="checkbox" id="orange" name="color" value="orange">
                                                            <label class="orange" for="orange"></label>
                                                            <input type="checkbox" id="skyblue" name="color"
                                                                value="skyblue">
                                                            <label class="skyblue" for="skyblue"></label>
                                                            <input type="checkbox" id="black" name="color" value="black">
                                                            <label class="black" for="black"></label>
                                                            <input type="checkbox" id="yellow" name="color" value="yellow">
                                                            <label class="yellow" for="yellow"></label>
                                                            <input type="checkbox" id="orange" name="color" value="orange">
                                                            <label class="orange" for="orange"></label> --}}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-section">
                                        <div class="accordion" id="accordionSize">
                                            <div class="card">
                                                <div class="card-head" id="headingThree">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseThree" aria-expanded="true"
                                                        aria-controls="collapseThree">
                                                        Size
                                                    </h6>
                                                </div>
                                                <div id="collapseThree" class="collapse show"
                                                    aria-labelledby="headingThree" data-parent="#accordionSize">
                                                    <div class="card-body">
                                                        @foreach ($sizes as $size)
                                                            <div class="form-group">
                                                                <label class="custom-checkbox">{{ $size->name }}
                                                                    <input type="checkbox" name="size[]"
                                                                        value="{{ $size->id }}">
                                                                    <span class="checkmark"></span>
                                                                </label>
                                                            </div>
                                                        @endforeach

                                                        {{-- <div class="form-group">
                                                            <label class="custom-checkbox">XL
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">L
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">M
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">S
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div> --}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-section">
                                        <div class="form-group mb-0 position-relative">
                                            <span class="search-icon"><i class="fas fa-search"></i></span>
                                            <input type="text" class="form-control" placeholder="Search"
                                                aria-label="Search Category">
                                        </div>
                                        <div class="accordion" id="accordionArtist">
                                            <div class="card">
                                                <div class="card-head" id="headingFour">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseFour" aria-expanded="true"
                                                        aria-controls="collapseFour">
                                                        Artist
                                                    </h6>
                                                </div>
                                                <div id="collapseFour" class="collapse show" aria-labelledby="headingFour"
                                                    data-parent="#accordionArtist">
                                                    <div class="card-body">
                                                        @foreach ($creators as $creator)
                                                            <div class="form-group">
                                                                <label
                                                                    class="custom-checkbox">{{ ucfirst($creator->user->name) }}
                                                                    <input type="checkbox" name="creator[]"
                                                                        value="{{ $creator->user->id }}">
                                                                    <span class="checkmark"></span>
                                                                </label>
                                                            </div>
                                                        @endforeach

                                                        {{-- <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">Nature background
                                                                <input type="checkbox">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div> --}}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="filter-section">
                                        <div class="accordion" id="accordionDiscounts">
                                            <div class="card">
                                                <div class="card-head" id="headingFive">
                                                    <h6 class="mb-0" data-toggle="collapse"
                                                        data-target="#collapseFive" aria-expanded="true"
                                                        aria-controls="collapseFive">
                                                        Discounts
                                                    </h6>
                                                </div>
                                                <div id="collapseFive" class="collapse show" aria-labelledby="headingFive"
                                                    data-parent="#accordionDiscounts">
                                                    <div class="card-body">
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">10% & Above Discount
                                                                <input type="checkbox" name="discount[]" value="10">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">20% & Above Discount
                                                                <input type="checkbox" name="discount[]" value="20">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">30% & Above Discount
                                                                <input type="checkbox" name="discount[]" value="30">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">40% & Above Discount
                                                                <input type="checkbox" name="discount[]" value="40">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="custom-checkbox">50% & Above Discount
                                                                <input type="checkbox" name="discount[]" value="50">
                                                                <span class="checkmark"></span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @csrf
                                    <div class="filter-btn-group">
                                        <div class="filter-btn">
                                            <button type="button" class="btn btn-black-brd" id="submit-form">Apply</button>
                                            <a href="#" class="btn btn-cancel">
                                                <div class="button_inner"><span data-text="Add to Cart">Add to
                                                        Cart</span></div>
                                            </a>
                                        </div>
                                    </div>
                                </form>
                            </aside>
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12">
                            <div id="filterd_product">
                                <div class="row">
                                    @foreach ($products as $product)
                                        <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                            <div class="product-list">
                                                <div class="arrival-info">
                                                    <a href="{{ url('product/detail') . '/' . $product->id }}">
                                                        <div class="product-img">
                                                            <span class="wishlist">
                                                                <i class='fal fa-heart'></i>
                                                            </span>
                                                            <figure>
                                                                {{-- <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                                alt="product-image"> --}}
                                                                <img src="{{ asset('public/assets/images/product') . '/' . $product->thumbnail }}"
                                                                    alt="product-image">
                                                            </figure>
                                                        </div>
                                                        <div class="arrival-content">
                                                            <h3>{{ ucfirst($product->name) }}</h3>
                                                            <div class="price-list"> <span
                                                                    class="grey-text">₹{{ max(json_decode($product->regular_price)) }}</span>
                                                                ₹{{ min(json_decode($product->sale_price)) }}<span
                                                                    class="percent">Save
                                                                    {{ $product->discount }}{{ $product->flat == '1' ? '₹ Flat' : '%' }}</span>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach

                                    {{-- <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-3.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-3.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-4 col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12">
                                    <div class="product-list">
                                        <div class="arrival-info">
                                            <a href="#">
                                                <div class="product-img">
                                                    <span class="wishlist">
                                                        <i class='fal fa-heart'></i>
                                                    </span>
                                                    <figure>
                                                        <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                            alt="product-image">
                                                    </figure>
                                                </div>
                                                <div class="arrival-content">
                                                    <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                                    <div class="price-list"> <span class="grey-text">₹599</span>
                                                        ₹399<span class="percent">Save 8%</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="trending-product">
                    <h2>Trending Products</h2>
                    <div class="trending-product-list">

                        @foreach ($products as $i => $product)
                            <div class="product-list">
                                <div class="arrival-info">
                                    <a href="{{ url('product/detail') . '/' . $product->id }}">
                                        <div class="product-img">
                                            <span class="wishlist">
                                                <i class='fal fa-heart'></i>
                                            </span>
                                            <figure>
                                                {{-- <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                                alt="product-image"> --}}
                                                <img src="{{ asset('public/assets/images/product') . '/' . $product->thumbnail }}"
                                                    alt="product-image">
                                            </figure>
                                        </div>
                                        <div class="arrival-content">
                                            <h3>{{ ucfirst($product->name) }}</h3>
                                            <div class="price-list"> <span
                                                    class="grey-text">₹{{ max(json_decode($product->regular_price)) }}</span>
                                                ₹{{ min(json_decode($product->sale_price)) }}<span
                                                    class="percent">Save
                                                    {{ $product->discount }}{{ $product->flat == '1' ? '₹ Flat' : '%' }}</span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            @if ($i == 4)
                            @break
                        @endif
                    @endforeach
                    {{-- <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="product-list">
                            <div class="arrival-info">
                                <a href="#">
                                    <div class="product-img">
                                        <span class="wishlist">
                                            <i class='fal fa-heart'></i>
                                        </span>
                                        <figure>
                                            <img src="http://localhost/alagsee-website/public/assets/images/product-img-2.jpg"
                                                alt="product-image">
                                        </figure>
                                    </div>
                                    <div class="arrival-content">
                                        <h3>Striped Captain America Full Sleeve T-Shirt</h3>
                                        <div class="price-list"> <span class="grey-text">₹599</span> ₹399<span
                                                class="percent">Save 8%</span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div> --}}








                </div>
            </div>
    </section>
</main>
<script src="{{ asset('public/assets/js/jquery.min.js') }}"></script>
<script>
    $(document).ready(function() {

        $('#submit-form').click(function() {
            var form = $('#productForm')[0];
            var data = new FormData(form);
            $.ajax({
                type: "POST",
                enctype: 'multipart/form-data',
                url: "{{ url('product-filter') }}",
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                timeout: 800000,
                success: function(data) {
                    // alert(data);
                    $('#filterd_product').html(data);
                },
                error: function(e) {

                    $("#output").text(e.responseText);
                    console.log("ERROR : ", e);
                    $("#btnSubmit").prop("disabled", false);
                }
            });
        })

    });
</script>
@stop
