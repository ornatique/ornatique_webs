@extends('frontend.template')
@section('main')
    <section class="my-cart-main">
        <div class="container">
            <!-- Breadcrumb Section -->
            <div class="breadcrumb-sec">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Library</li>
                    </ol>
                </nav>
            </div>
            <!-- My cart and payment section -->
            <div class="cart-payment-wrapper">
                <div class="row">
                    <div class="col-xl-7">
                        <div class="cart-list">
                            <h2 class="inner-page-title">MY CART</h2>
                            <div class="cart-product-list">
                                <div class="select-all-item">
                                    <div class="checkbox-green-group">
                                        <label class="checkbox-green">Select All
                                            <input type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                </div>
                                <!-- Cart item -->
                                <div class="cart-item">
                                    <div class="cart-item-left">
                                        <div class="checkbox-green-group">
                                            <label class="checkbox-green">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <div class="cart-item-img">
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </div>
                                    </div>
                                    <div class="cart-item-detail">
                                        <div class="cart-item-title-detail">
                                            <h6>Striped Captain America Printed Badge Full Sleeve T-Shirt</h6>
                                            <div class="price-size-quantity">
                                                <h4>₹399</h4>
                                                <div class="size-quantity">
                                                    <div class="form-group mb-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Size: XL</option>
                                                            <option>Size: XXL</option>
                                                            <option>Size: L</option>
                                                            <option>Size: M</option>
                                                            <option>Size: S</option>
                                                        </select>
                                                    </div>
                                                    <div class="qty-input">
                                                        <button type="button" id="sub" class="sub qty-count">-</button>
                                                        <input class="count" type="text" id="1" value="1" min="1"
                                                            max="100" />
                                                        <button type="button" id="add" class="add qty-count">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cart-item-btn-group">
                                            <a href="#" class="btn btn-black-brd">Move wishlist</a>
                                            <a href="#" class="btn btn-black-brd">Delete item</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-item">
                                    <div class="cart-item-left">
                                        <div class="checkbox-green-group">
                                            <label class="checkbox-green">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <div class="cart-item-img">
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </div>
                                    </div>
                                    <div class="cart-item-detail">
                                        <div class="cart-item-title-detail">
                                            <h6>Striped Captain America Printed Badge Full Sleeve T-Shirt</h6>
                                            <div class="price-size-quantity">
                                                <h4>₹399</h4>
                                                <div class="size-quantity">
                                                    <div class="form-group mb-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Size: XL</option>
                                                            <option>Size: XXL</option>
                                                            <option>Size: L</option>
                                                            <option>Size: M</option>
                                                            <option>Size: S</option>
                                                        </select>
                                                    </div>
                                                    <div class="qty-input">
                                                        <button type="button" id="sub" class="sub qty-count">-</button>
                                                        <input class="count" type="text" id="1" value="1" min="1"
                                                            max="100" />
                                                        <button type="button" id="add" class="add qty-count">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cart-item-btn-group">
                                            <a href="#" class="btn btn-black-brd">Move wishlist</a>
                                            <a href="#" class="btn btn-black-brd">Delete item</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-item">
                                    <div class="cart-item-left">
                                        <div class="checkbox-green-group">
                                            <label class="checkbox-green">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <div class="cart-item-img">
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </div>
                                    </div>
                                    <div class="cart-item-detail">
                                        <div class="cart-item-title-detail">
                                            <h6>Striped Captain America Printed Badge Full Sleeve T-Shirt</h6>
                                            <div class="price-size-quantity">
                                                <h4>₹399</h4>
                                                <div class="size-quantity">
                                                    <div class="form-group mb-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Size: XL</option>
                                                            <option>Size: XXL</option>
                                                            <option>Size: L</option>
                                                            <option>Size: M</option>
                                                            <option>Size: S</option>
                                                        </select>
                                                    </div>
                                                    <div class="qty-input">
                                                        <button type="button" id="sub" class="sub qty-count">-</button>
                                                        <input class="count" type="text" id="1" value="1" min="1"
                                                            max="100" />
                                                        <button type="button" id="add" class="add qty-count">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cart-item-btn-group">
                                            <a href="#" class="btn btn-black-brd">Move wishlist</a>
                                            <a href="#" class="btn btn-black-brd">Delete item</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-item">
                                    <div class="cart-item-left">
                                        <div class="checkbox-green-group">
                                            <label class="checkbox-green">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <div class="cart-item-img">
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </div>
                                    </div>
                                    <div class="cart-item-detail">
                                        <div class="cart-item-title-detail">
                                            <h6>Striped Captain America Printed Badge Full Sleeve T-Shirt</h6>
                                            <div class="price-size-quantity">
                                                <h4>₹399</h4>
                                                <div class="size-quantity">
                                                    <div class="form-group mb-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Size: XL</option>
                                                            <option>Size: XXL</option>
                                                            <option>Size: L</option>
                                                            <option>Size: M</option>
                                                            <option>Size: S</option>
                                                        </select>
                                                    </div>
                                                    <div class="qty-input">
                                                        <button type="button" id="sub" class="sub qty-count">-</button>
                                                        <input class="count" type="text" id="1" value="1" min="1"
                                                            max="100" />
                                                        <button type="button" id="add" class="add qty-count">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cart-item-btn-group">
                                            <a href="#" class="btn btn-black-brd">Move wishlist</a>
                                            <a href="#" class="btn btn-black-brd">Delete item</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="cart-item">
                                    <div class="cart-item-left">
                                        <div class="checkbox-green-group">
                                            <label class="checkbox-green">
                                                <input type="checkbox">
                                                <span class="checkmark"></span>
                                            </label>
                                        </div>
                                        <div class="cart-item-img">
                                            <img src="{{ asset('public/assets/images/product-img-2.jpg') }}"
                                                alt="product-image">
                                        </div>
                                    </div>
                                    <div class="cart-item-detail">
                                        <div class="cart-item-title-detail">
                                            <h6>Striped Captain America Printed Badge Full Sleeve T-Shirt</h6>
                                            <div class="price-size-quantity">
                                                <h4>₹399</h4>
                                                <div class="size-quantity">
                                                    <div class="form-group mb-0">
                                                        <select class="form-control" id="exampleFormControlSelect1">
                                                            <option>Size: XL</option>
                                                            <option>Size: XXL</option>
                                                            <option>Size: L</option>
                                                            <option>Size: M</option>
                                                            <option>Size: S</option>
                                                        </select>
                                                    </div>
                                                    <div class="qty-input">
                                                        <button type="button" id="sub" class="sub qty-count">-</button>
                                                        <input class="count" type="text" id="1" value="1" min="1"
                                                            max="100" />
                                                        <button type="button" id="add" class="add qty-count">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="cart-item-btn-group">
                                            <a href="#" class="btn btn-black-brd">Move wishlist</a>
                                            <a href="#" class="btn btn-black-brd">Delete item</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5">
                        <div class="payment-summary">
                            <h2 class="inner-page-title">PAYMENT SUMMERY</h2>
                            <div class="payment-summary-content-outer">
                                <div class="payment-summary-content">
                                    <div class="sb-promo">
                                        <input class="form-control" type="text" placeholder="Default input">
                                        <a href="#" class="btn btn-black-brd">Apply</a>
                                    </div>
                                    <div class="order-summary">
                                        <div class="charge-price">
                                            <span>Cart Total</span>
                                            <span>₹1596</span>
                                        </div>
                                        <div class="charge-price">
                                            <span>Shipping Charges</span>
                                            <span>₹40</span>
                                        </div>
                                        <div class="charge-price sub-total">
                                            <span>Sub Total</span>
                                            <span>₹1695.30</span>
                                        </div>
                                    </div>
                                    <div class="discount-rate">
                                        <div class="charge-price">
                                            <div class="discount-text">
                                                <span>Purchase Options At Discount Rate</span>
                                                <span class="grey-text">Buy Digital Assets in Discount Rate</span>
                                                <span class="claim">Claim free assets of the day </span>
                                                <a href="#" class="see-video">See Video (Except T&C) </a>
                                            </div>
                                            <div class="price-add">
                                                <span>₹1596</span>
                                                <span class="add">Add</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="total-payment">
                                        <div class="charge-price">
                                            <div class="total-including">
                                                <span>Cart Total</span>
                                                <span class="grey-text">Including ₹16.30 in taxes </span>
                                            </div>
                                            <span>₹1596</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="place-order">
                                    <div class="place-order-btn-group">
                                        <a href="#" class="yellow-btn">
                                            <div class="button_inner"><span data-text="Place Order">Place Order</span>
                                            </div>
                                        </a>
                                        <a href="#" class="btn btn-round">Place Order</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="more-product">
                <div class="more-product-btn">
                    <div>
                        <a href="#" class="yellow-btn">
                            <div class="button_inner"><span data-text="ADD MORE PRODUCTS">ADD MORE PRODUCTS</span></div>
                        </a>
                    </div>
                    <div>
                        <a href="#" class="btn btn-round">ADD MORE PRODUCTSs</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
@stop
