<!DOCTYPE html>
<html>

<head>
    <!-- Required meta tags -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1, maximum-scale=1" />
    <meta charset="UTF-8">
    <!-- Required Title -->
    <title>AlagSEE</title>

    <link rel="icon" href="{{ asset('public/assets/admin/images/favicon.png') }}" type="image/png" />
    {{-- <link rel="icon" type="image/png" href="assets/images/favicon.png" sizes="32x32" /> --}}

    <!--fa-fa icons-->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <!-- Stylesheets -->
    <link href="{{ asset('public/assets/fonts/fonts.css') }}" rel="stylesheet" type="text/css" />
    <!-- Bootstrap 4 css-->
    <link href="{{ asset('public/assets/css/bootstrap.css') }}" rel="stylesheet" type="text/css" />
    <!-- Bootstrap 4 select css -->
    <link href="{{ asset('public/assets/css/bootstrap-select.min.css') }}" rel="stylesheet" type="text/css" />
    <!-- Font Flaticon css -->
    <link href="{{ asset('public/assets/css/flaticon.css') }}" rel="stylesheet" type="text/css" />
    <!-- jquery-ui css -->
    <link href="{{ asset('public/assets/css/jquery-ui.css') }}" rel="stylesheet" type="text/css" />
    <!-- Slick css -->
    <!-- <link href="assets/css/aos.css" rel="stylesheet" type="text/css"/> -->
    <link href="{{ asset('public/assets/css/slick.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('public/assets/css/slick-theme.css') }}" rel="stylesheet" type="text/css" />
    <!-- Slick css -->
    <link href="{{ asset('public/assets/css/style.css') }}" rel="stylesheet" type="text/css" />
</head>

<body class="">
    <!--- START header -->
    <div class="header-height-bar" style="min-height: 122px;"></div>
    <header class="header_wrapper stickyHeader">
        <div class="container-fluid">
            <div class="row align-items-center mobile-hide">
                <div class="col-12 col-md-4">
                    <ul class="d-flex flex-wrap">
                        <li><a href="{{ url('product/list') }}">MEN</a></li>
                        <li><a href="{{ url('product/list') }}">WOMEN</a></li>
                        <li><a href="#">DIGITAL ASSETS</a></li>
                    </ul>
                </div>
                <div class="col-12 col-md-4 text-center main-logo">
                    <figure><a href="{{ url('/') }}"><img src="{{ asset('public/assets/images/logo.svg') }}"
                                alt="logo"></a>
                    </figure>
                </div>
                <div class="col-12 col-md-4 text-right user-info">
                    <ul class="d-flex flex-wrap justify-content-end">
                        <li><a href="{{ url('/cart') }}"><img
                                    src="{{ asset('public/assets/images/shopping-bag.svg') }}"></a></li>
                        <li><a href="{{ url('wishlist') }}"><img
                                    src="{{ asset('public/assets/images/heart-empty.svg') }}"></a></li>
                        <li><a href="#"><img src="{{ asset('public/assets/images/user-icon.svg') }}"></a></li>
                    </ul>
                    <p>AlagSEE DESIGNER</p>
                </div>
            </div>
            <!-- Mobile Nav -->
            <div class="row desktop-hide">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="{{ url('/') }}"><img
                            src="{{ asset('public/assets/images/logo.svg') }}" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation"><img
                            src="{{ asset('public/assets/images/menu.png') }}"></button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li><a href="{{ url('product/list') }}">MEN</a></li>
                            <li><a href="{{ url('product/list') }}">WOMEN</a></li>
                            <li><a href="#">DIGITAL ASSETS</a></li>
                        </ul>
                        <ul class="d-flex flex-wrap justify-content-center">
                            <li><a href="{{ url('/cart') }}"><img
                                        src="{{ asset('public/assets/images/shopping-bag.svg') }}"></a></li>
                            <li><a href="{{ url('wishlist') }}"><img
                                        src="{{ asset('public/assets/images/heart-empty.svg') }}"></a></li>
                            <li><a href="#"><img src="{{ asset('public/assets/images/user-icon.svg') }}"></a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>

    </header>
    <!---END header -->

    <body>
        @yield('main')
    </body>
    <!-- Footer -->
    <footer class="black-bg footer">
        <div class="container">
            <div class="row top-footer">
                <div class="col-md-4 social-icon">
                    <h4>Connect with us</h4>
                    <ul class="d-flex flex-wrap">
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/fb.svg') }}"
                                    alt="FB"></a></li>
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/insta.svg') }}"
                                    alt="insta"></a></li>
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/linkedin.svg') }}"
                                    alt="linkedin"></a></li>
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/pintest.svg') }}"
                                    alt="Pintest"></a></li>
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/youtube.svg') }}"
                                    alt="youtube"></a></li>
                    </ul>
                </div>
                <div class="col-md-4 footer-logo">
                    <figure><a href="#"><img src="{{ asset('public/assets/images/alagSee-logo.png') }}"
                                alt="footer logo"></a></figure>
                </div>
                <div class="col-md-4 experience-app">
                    <h4>Experience the App</h4>
                    <ul class="d-flex flex-wrap">
                        <li><a href="#" target="_blank"><img src="{{ asset('public/assets/images/app-store.png') }}"
                                    alt=""></a></li>
                        <li><a href="#" target="_blank"><img
                                    src="{{ asset('public/assets/images/google-play.png') }}" alt=""></a></li>
                    </ul>
                </div>
            </div>
            <!-- Bottom -->
            <div class="row bottom-footer">
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <h4><span>Customer Service</span></h4>
                    <ul>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Track Order</a></li>
                        <li><a href="#">Cancel Order</a></li>
                        <li><a href="#">Return Order</a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <h4><span>Quick Links</span></h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">AlagSEE Designer</a></li>
                        <li><a href="#">How It Works</a></li>
                        <li><a href="#">Terms & Condition</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-2">
                    <h4><span>Shop</span></h4>
                    <ul>
                        <li><a href="#">Men's Tshirt</a></li>
                        <li><a href="#">Women's Tshirt</a></li>
                        <li><a href="#">Kid's Tshirt</a></li>
                        <li><a href="#">Cart</a></li>
                        <li><a href="#">Checkout</a></li>
                        <li><a href="#">My Account</a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-4 subscribe">
                    <h4><span>Subscribe</span></h4>
                    <p>When an unknown printer took a galley of type and scrambled it to make a type</p>
                    <div class="input-group">
                        <div class="form-outline">
                            <input type="search" id="form1" class="form-control" placeholder="Enter your email" />
                        </div>
                        <button type="button" class="btn btn-primary">SUBMIT</button>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 text-center">
                    <p>© 2022 <a href="AlagSEE.com">AlagSEE.com</a> | All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>
    <!-- jQuery js -->
    <script src="{{ asset('public/assets/js/jquery.min.js') }}"></script>
    <!-- Bootstrap 4 dependency popper js  -->
    <script src="{{ asset('public/assets/js/popper.min.js') }}"></script>
    <!-- Bootstrap 4 js -->
    <script src="{{ asset('public/assets/js/bootstrap.min.js') }}"></script>
    <!-- Bootstrap 4 select js -->
    <script src="{{ asset('public/assets/js/bootstrap-select.min.js') }}"></script>
    <!-- <script src="assets/js/aos.js"></script>         -->
    <!-- slick js -->
    <script src="{{ asset('public/assets/js/slick.min.js') }}" type="text/javascript"></script>
    <!-- Custome js -->
    <script src="{{ asset('public/assets/js/custom.js') }}"></script>
</body>

</html>
