<form action="{{ route('feedback') }}" method="POST">
    @csrf
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Subject</label>
                <input required type="text" class="form-control  @error('subject') is-invalid @enderror" id="subject"
                    placeholder="Enter Subject" name="subject" value="{{ old('subject') }}">
                @error('subject')
                    <span class="invalid-feedback" role="alert">
                        <strong class="text-danger">{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <label>Message</label>
                <textarea required type="text" class="form-control  @error('message') is-invalid @enderror" id="message" name="message"
                    value="{{ old('message') }}" rows="3"> </textarea>
                @error('message')
                    <span class="invalid-feedback" role="alert">
                        <strong class="text-danger">{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-lg-12">
            <button class="btn btn-primary" type="submit">Submit</button>
        </div>
    </div>
</form>
