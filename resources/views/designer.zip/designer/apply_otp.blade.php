@include('designer.header')
<section class="designer-auth-section"
    style="background-image: url('{{ asset('public/assets/images/designer-login-bg.png') }}')">
    <div class="container">
        <div class="text-center logo">
            <figure class="m-0"><a href="{{ url('/') }}"><img
                        src="{{ asset('public/assets/images/designer-logo.png') }}" alt="Logo"></a>
            </figure>
        </div>
        <div class="designer-auth">
            <p class="creator-name text-white mb-0 text-right">
                <label>Created by</label>
                <span>@maxsteve</span>
            </p>
            <div class="p-0 m-0 row">
                <div class="p-0 col-md-4">
                    <div class="auth-form position-relative">
                        <h2>ENTER OTP</h2>
                        <p class="mb-4">We've sent an OTP to your phone number.</p>
                        <div class="login-form">
                            <form action="#">
                                <div class="form-group">
                                    <input placeholder="Phone number" type="text" class="form-control"
                                        name="phonenumber" value="1234567890">
                                </div>
                                <div class="form-group">
                                    <input placeholder="One time password" type="number" class="form-control"
                                        name="otp">
                                    <div class="pt-2 text-center"><a href="#"
                                            style="color: var(--themeCyan)">Resend</a>
                                    </div>
                                </div>
                                <div class="form-group text-left">
                                    <a href="{{ url('designer/apply-form') }}" class="btn-block yellow-btn"
                                        type="submit" style="cursor: pointer">
                                        <div class="button_inner text-center"><span data-text="Verify OTP">Verify
                                                OTP</span></div>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <div class="p-0 col-md-1"></div>
                <div class="p-0 col-md-7">
                    <div class="designer-bg">
                        <img src="{{ asset('public/assets/images/designer-img1.jpg') }}" alt="Logo">
                    </div>
                </div>
            </div>
        </div>
        <div class="designer-content">
            <h5><i>Step in to the</i></h5>
            <h3><i>Creator's Cosmos</i></h3>
        </div>
    </div>
</section>
@include('designer.footer')
