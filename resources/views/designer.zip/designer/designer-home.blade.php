@include('designer.header')
<section class="home-banner-section" style="background-image: url('{{asset('public/assets/images/home-banner.png')}}')">
</section>

<section class="designer-assets-section">
    <div class="container">
        <div class="designer-container">
            <div class="designer-assets-list">
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/gorilla.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/how-work-img2.jpg')}}"
                                        alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/gorilla.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/how-work-img2.jpg')}}"
                                        alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/gorilla.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="#">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="product-list">
                    <div class="arrival-info">
                        <a href="http://localhost/alagsee-website/product/detail/19">
                            <div class="product-img">
                                <figure><img src="{{asset('public/assets/images/how-work-img2.jpg')}}"
                                        alt="product-image">
                                </figure>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <h2 class="my-4">FREQUENTLY ASKED QUESTIONS</h2>
            <div class="contact-tab">
                <div class="faq-section">
                    <div id="accordion1">
                        <div class="card">
                            <div class="card-header" id="heading-1">
                                <h5 class="mb-0">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
                                        aria-expanded="false" aria-controls="collapse-1">
                                        1. What is AlagSEE Designer?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-1" class="collapse" data-parent="#accordion1" aria-labelledby="heading-1"
                                style="">
                                <div class="card-body">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. enas
                                        consectetur luctus tellus, a aliquam tellus mattis ut.
                                        Vestibulum
                                        bibendum efficitur felis non blandit.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="accordion2">
                        <div class="card">
                            <div class="card-header" id="heading-2">
                                <h5 class="mb-0">
                                    <a class="" role="button" data-toggle="collapse" href="#collapse-2"
                                        aria-expanded="false" aria-controls="collapse-2">
                                        2. How do I make a premium user?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-2" class="collapse" data-parent="#accordion2" aria-labelledby="heading-2">
                                <div class="card-body">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. enas
                                        consectetur luctus tellus, a aliquam tellus mattis ut.
                                        Vestibulum
                                        bibendum efficitur felis non blandit.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="accordion3">
                        <div class="card">
                            <div class="card-header" id="heading-3">
                                <h5 class="mb-0">
                                    <a class="" role="button" data-toggle="collapse" href="#collapse-3"
                                        aria-expanded="false" aria-controls="collapse-3">
                                        3. How do I make a premium user?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-3" class="collapse" data-parent="#accordion3" aria-labelledby="heading-3">
                                <div class="card-body">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. enas
                                        consectetur luctus tellus, a aliquam tellus mattis ut.
                                        Vestibulum
                                        bibendum efficitur felis non blandit.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="accordion4">
                        <div class="card">
                            <div class="card-header" id="heading-4">
                                <h5 class="mb-0">
                                    <a class="" role="button" data-toggle="collapse" href="#collapse-4"
                                        aria-expanded="false" aria-controls="collapse-4">
                                        4. Is this App suitable for your team?
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse-4" class="collapse" data-parent="#accordion4" aria-labelledby="heading-4">
                                <div class="card-body">
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. enas
                                        consectetur luctus tellus, a aliquam tellus mattis ut.
                                        Vestibulum
                                        bibendum efficitur felis non blandit.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</section>

<section class="designer-blog-section">
    <div class="container">
        <div class="designer-container">
            <h2 class="">OUR BLOG</h2>
            <div class="designer-assets-list d-none">
                <div class="product-list product-list-digital">
                    <div class="arrival-info">

                        <a href="javascript:void(0)">
                            <div class="product-img">
                                <img src="{{asset('public/assets/images/funk.jpg')}}" alt="product-image">
                            </div>
                            <div class="arrival-content">
                                <h3>There are many variations of passages of Lorem test majority</h3>
                                <span>By John Doe</span>
                                <button class="yellow-btn add_cart" id="cart_button">
                                    <div class="button_inner"><span data-text="Add to Cart" style="cursor: pointer">Add
                                            to
                                            Cart</span></div>
                                </button>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
@include('designer.footer')